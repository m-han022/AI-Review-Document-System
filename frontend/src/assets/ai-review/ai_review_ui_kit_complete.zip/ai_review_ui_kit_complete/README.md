# AI Review UI Kit Complete

Bộ này gồm đầy đủ thứ cần để tạo UI/UX giống dashboard ảnh mẫu:

## 01_design_spec
- Design tokens
- UI requirements

## 02_assets
- Header background
- Sidebar icons SVG
- AI robot illustration
- AI cube object

## 03_code_snippets
- CSS variables / design tokens

## 04_codex_agent
- Prompt đưa cho Codex Agent
- AGENTS.md đặt ở root repo

## Cách dùng nhanh
1. Copy `02_assets` vào project:
   `/public/assets/ai-review`

2. Copy CSS tokens vào global CSS.

3. Gửi `04_codex_agent/CODEX_PROMPT.txt` cho Codex Agent.

4. Đặt `AGENTS.md` ở root repo để Codex làm đúng hướng.

## Lưu ý
Để giống 100%, phần quan trọng nhất là code layout + CSS pixel-level, không phải chỉ ảnh.