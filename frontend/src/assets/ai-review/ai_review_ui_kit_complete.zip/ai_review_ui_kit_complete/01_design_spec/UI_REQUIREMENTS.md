# AI Review Dashboard UI Requirements

## Goal
Create a web app UI matching the provided AI Review Dashboard screenshot as closely as possible.

## Required layout
- Page padding: 18px
- Sidebar width: 260px
- Main gap: 18px
- Card gap: 16px
- Sidebar: fixed left area
- Content: topbar, hero, KPI grid, middle grid, bottom grid

## Required components
1. Sidebar
   - Logo/brand block
   - Menu items with rounded icon boxes
   - Active state with light gradient background
   - AI assistant card
   - AI engine status card

2. Topbar
   - Search box
   - AI engine button
   - Language button

3. Hero/header
   - White/glass card
   - AI decorative object on top-right
   - Dot pattern background
   - Date filter
   - Export report button

4. KPI cards
   - 4 cards
   - Big score number
   - Total count
   - Donut chart
   - Green/red legend

5. Middle section
   - Top 5 high score documents
   - Top 5 comments
   - Improvement criteria
   - Slide summary donut chart

6. Bottom section
   - Top 3 projects with progress bars
   - Review history table

## Must use
- Font: Noto Sans JP
- Rounded cards
- Soft shadows
- Pastel AI blue/purple gradient
- SVG icons, not raster icons
