# AGENTS.md

## UI update rules
- Preserve existing business logic, API calls, routing and state.
- UI should match the AI Review Dashboard screenshot.
- Use assets from `/public/assets/ai-review`.
- Prefer SVG assets.
- Use Noto Sans JP.
- Use rounded glass cards, soft shadows, pastel blue/purple AI gradient.
- Run build/lint/test when available.